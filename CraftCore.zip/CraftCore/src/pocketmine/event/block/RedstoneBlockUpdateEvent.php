<?php
namespace pocketmine\event\block;

//use pocketmine\event\Cancellable;

/**
 * Called when a block gets a redstone update
 */
class RedstoneBlockUpdateEvent extends BlockEvent{ //implements Cancellable
	public static $handlerList = null;

}