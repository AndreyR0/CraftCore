<?php
/**
 * Events related to the server core, like networking, stop, level loading
 */
namespace pocketmine\event\server;

use pocketmine\event\Event;

abstract class ServerEvent extends Event{

}