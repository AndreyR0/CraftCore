<?php

namespace milk\pureentities\entity;

abstract class JumpingEntity extends BaseEntity{

    protected function checkTarget(){
        //TODO
    }

    public function updateMove($tickDiff){
        // TODO
        return null;
    }
}